// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Get references to the text input and all display elements
    const textInput = document.getElementById('textInput');
    const wordCountElement = document.getElementById('wordCount');
    const complicatedWordsElement = document.getElementById('complicatedWords');
    const sentenceCountElement = document.getElementById('sentenceCount');
    const characterCountElement = document.getElementById('characterCount');
    const characterCountNoSpacesElement = document.getElementById('characterCountNoSpaces');
    const averageWordLengthElement = document.getElementById('averageWordLength');
    
    // Function to count words in text
    function countWords(text) {
        if (!text.trim()) return 0;
        // Split by whitespace and filter out empty strings
        const words = text.trim().split(/\s+/).filter(word => word.length > 0);
        return words.length;
    }
    
    // Function to get array of words for further analysis
    function getWords(text) {
        if (!text.trim()) return [];
        return text.trim().split(/\s+/).filter(word => word.length > 0);
    }
    
    // Function to count complicated words (10+ characters)
    function countComplicatedWords(text) {
        const words = getWords(text);
        return words.filter(word => {
            // Remove punctuation for accurate character count
            const cleanWord = word.replace(/[^\w]/g, '');
            return cleanWord.length >= 10;
        }).length;
    }
    
    // Function to count sentences
    function countSentences(text) {
        if (!text.trim()) return 0;
        // Split by sentence-ending punctuation and filter out empty strings
        const sentences = text.split(/[.!?]+/).filter(sentence => sentence.trim().length > 0);
        return sentences.length;
    }
    
    // Function to count total characters
    function countCharacters(text) {
        return text.length;
    }
    
    // Function to count characters without spaces
    function countCharactersNoSpaces(text) {
        return text.replace(/\s/g, '').length;
    }
    
    // Function to calculate average word length
    function calculateAverageWordLength(text) {
        const words = getWords(text);
        if (words.length === 0) return 0;
        
        const totalLength = words.reduce((sum, word) => {
            // Remove punctuation for accurate word length
            const cleanWord = word.replace(/[^\w]/g, '');
            return sum + cleanWord.length;
        }, 0);
        
        return (totalLength / words.length).toFixed(1);
    }
    
    // Function to update all statistics
    function updateStats() {
        const text = textInput.value;
        
        // Update word count
        const wordCount = countWords(text);
        wordCountElement.textContent = wordCount;
        
        // Update complicated words count
        const complicatedWords = countComplicatedWords(text);
        complicatedWordsElement.textContent = complicatedWords;
        
        // Update sentence count
        const sentenceCount = countSentences(text);
        sentenceCountElement.textContent = sentenceCount;
        
        // Update character count
        const characterCount = countCharacters(text);
        characterCountElement.textContent = characterCount;
        
        // Update character count without spaces
        const characterCountNoSpaces = countCharactersNoSpaces(text);
        characterCountNoSpacesElement.textContent = characterCountNoSpaces;
        
        // Update average word length
        const averageWordLength = calculateAverageWordLength(text);
        averageWordLengthElement.textContent = averageWordLength;
    }
    
    // Add event listeners for real-time updates
    // 'input' event fires every time the user types or deletes
    textInput.addEventListener('input', updateStats);
    
    // Also listen for paste events
    textInput.addEventListener('paste', function() {
        // Small delay to ensure pasted content is processed
        setTimeout(updateStats, 10);
    });
    
    // Initialize stats with empty values
    updateStats();
    
    // Optional: Add some sample text for demonstration
    const sampleButton = document.createElement('button');
    sampleButton.textContent = 'Load Sample Text';
    sampleButton.style.cssText = `
        margin-top: 10px;
        padding: 8px 16px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
    `;
    
    sampleButton.addEventListener('click', function() {
        textInput.value = "This is a demonstration of the real-time word counter application. As you type, the statistics automatically update to show various measurements of your text. The application counts regular words, complicated words that are ten characters or longer, sentences, total characters, characters without spaces, and calculates the average word length. This functionality provides comprehensive analysis of your writing in real-time!";
        updateStats();
        textInput.focus();
    });
    
    // Add the sample button after the text input
    textInput.parentNode.insertBefore(sampleButton, textInput.nextSibling);
});