
function Contact(name, address, phoneNumber) {
    this.name = name;
    this.address = address;
    this.phoneNumber = phoneNumber;
}

let contacts = [
    new Contact("Alice Johnson", "123 Main St, Anytown, USA", "555-0123"),
    new Contact("Bob Smith", "456 Oak Ave, Somewhere, USA", "555-0456"),
    new Contact("Charlie Brown", "789 Pine Rd, Nowhere, USA", "555-0789")
];


const maxContacts = 10;

function createContactFromInput() {
    const name = prompt("Enter contact name:");
    if (name === null) return null; // User cancelled
    
    const address = prompt("Enter contact address:");
    if (address === null) return null; // User cancelled
    
    const phoneNumber = prompt("Enter contact phone number:");
    if (phoneNumber === null) return null; // User cancelled
    
    return new Contact(name, address, phoneNumber);
}


function addContacts() {
    while (contacts.length < maxContacts) {
        const newContact = createContactFromInput();
        
        if (newContact === null) {
            break;
        }
      
        contacts.push(newContact);
        console.log(`Contact "${newContact.name}" added successfully!`);
        
        if (contacts.length >= maxContacts) {
            alert("Maximum number of contacts (10) has been reached!");
            break;
        }
        
        const addMore = confirm("Would you like to add another contact?");
        if (!addMore) {
            break;
        }
    }
}

function sortContactsByName() {
    contacts.sort((a, b) => {
        return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
    });
}

function displayContacts() {
    console.log("\n=== CONTACT LIST ===");
    console.log(`Total contacts: ${contacts.length}`);
    console.log("====================");
    
    contacts.forEach((contact, index) => {
        console.log(`${index + 1}. Name: ${contact.name}`);
        console.log(`   Address: ${contact.address}`);
        console.log(`   Phone: ${contact.phoneNumber}`);
        console.log("-------------------");
    });
}


function main() {
    console.log("Welcome to the Contact List Manager!");
    console.log("Starting with 3 initial contacts...\n");
    
    
    console.log("Initial contacts:");
    displayContacts();
    
 
    console.log("\nYou can now add more contacts...");
    addContacts();
    
  
    console.log("\nSorting contacts by name...");
    sortContactsByName();
    
    
    console.log("\nFinal sorted contact list:");
    displayContacts();
}


main();