

function calculateGrades() {
    // Requirement 1: Prompt for number of assignments (max 10)
    let numAssignments;
    do {
        numAssignments = parseInt(prompt("Enter the number of assignments to grade (maximum 10):"));
        if (isNaN(numAssignments) || numAssignments < 1 || numAssignments > 10) {
            alert("Please enter a valid number between 1 and 10.");
        }
    } while (isNaN(numAssignments) || numAssignments < 1 || numAssignments > 10);

    let totalScore = 0;
    
    console.log(`\nEntering scores for ${numAssignments} assignments:`);
    
    // Requirement 2: Loop to gather scores and calculate continuous average
    for (let i = 0; i < numAssignments; i++) {
        let score;
        do {
            score = parseFloat(prompt(`Enter score for assignment ${i + 1} (0-100):`));
            if (isNaN(score) || score < 0 || score > 100) {
                alert("Please enter a valid percentage between 0 and 100.");
            }
        } while (isNaN(score) || score < 0 || score > 100);
        
        totalScore += score;
        
        // Calculate continuous average
        let currentAverage = totalScore / (i + 1);
        console.log(`Assignment ${i + 1}: ${score}% - Current Average: ${currentAverage.toFixed(2)}%`);
    }
    
    // Requirement 3: When data entry completed, call function to calculate and display letter grade
    let finalAverage = totalScore / numAssignments;
    console.log("\nData entry completed!");
    calculateAndDisplayLetterGrade(finalAverage);
}

function calculateAndDisplayLetterGrade(average) {
    let letterGrade;
    
    if (average >= 90) {
        letterGrade = 'A';
    } else if (average >= 80) {
        letterGrade = 'B';
    } else if (average >= 70) {
        letterGrade = 'C';
    } else if (average >= 60) {
        letterGrade = 'D';
    } else {
        letterGrade = 'F';
    }
    
    // Display the final grade results
    console.log("\n=== FINAL GRADE RESULTS ===");
    console.log(`Final Average: ${average.toFixed(2)}%`);
    console.log(`Letter Grade: ${letterGrade}`);
    console.log("============================");
}

function gradeCalculatorProgram() {
    console.log("=== Welcome to Grade Calculator ===\n");
    
    let continueProgram = true;
    
  
    while (continueProgram) {
        calculateGrades();
        
        // Requirement 4: Prompt user to determine if they would like to repeat the program
        continueProgram = confirm("Would you like to calculate grades for another set of assignments?");
        
        if (continueProgram) {
            console.log("\n--- Starting New Grade Calculation ---\n");
        }
    }
    
    console.log("\nThank you for using the Grade Calculator!");
}

// Start the program
gradeCalculatorProgram();
