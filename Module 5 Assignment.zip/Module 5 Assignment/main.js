
document.addEventListener('DOMContentLoaded', function() {
   
    const passwordForm = document.getElementById('passwordForm');
    const messageDiv = document.getElementById('message');
  
    passwordForm.addEventListener('submit', function(event) {
       
        event.preventDefault();
    
        const password = document.getElementById('newPassword').value;
        
     
        validatePassword(password);
    });
    
    function validatePassword(password) {
      
        let errors = [];
        
        
        if (password.length < 8) {
            errors.push("Password must be at least 8 characters long");
        }
        
      
        let hasUpperCase = /[A-Z]/.test(password);
        if (!hasUpperCase) {
            errors.push("Password must contain at least one uppercase letter");
        }
        
      
        let hasLowerCase = /[a-z]/.test(password);
        if (!hasLowerCase) {
            errors.push("Password must contain at least one lowercase letter");
        }
        
      
        let hasNumber = /[0-9]/.test(password);
        if (!hasNumber) {
            errors.push("Password must contain at least one number");
        }
        
       
        displayMessage(errors);
    }
    
    function displayMessage(errors) {
        const messageDiv = document.getElementById('message');
        
        
        messageDiv.innerHTML = '';
        messageDiv.style.display = 'block';
        
        if (errors.length === 0) {
          
            messageDiv.className = 'message success';
            messageDiv.innerHTML = '<strong>Success!</strong> Your password is acceptable and meets all requirements.';
        } else {
         
            messageDiv.className = 'message error';
            let errorHTML = '<strong>Password validation failed:</strong><ul>';
            
            errors.forEach(function(error) {
                errorHTML += '<li>' + error + '</li>';
            });
            
            errorHTML += '</ul>';
            messageDiv.innerHTML = errorHTML;
        }
    }
});